Mergeconfigs is a package that help managing YAML configuration files

Mergeconfigs makes easy to merge several yaml files into one, using includes, placeholders and extends.
That way you can split your configurations into several files and merge them into one single yaml.  

Run `python -m mergeconfigs --help` for help
